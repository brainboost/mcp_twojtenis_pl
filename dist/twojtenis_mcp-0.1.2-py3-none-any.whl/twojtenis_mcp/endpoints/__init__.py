"""MCP endpoint implementations for TwojTenis server."""
