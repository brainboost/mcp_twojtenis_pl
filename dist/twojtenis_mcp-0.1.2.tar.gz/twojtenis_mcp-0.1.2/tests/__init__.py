"""Tests for TwojTenis MCP server."""
